# Cópia do Trello

Bem-vindo a Copia do Trello! Este é um aplicativo web de aprendizado que replica funcionalidades do Trello. Crie quadros, listas e cartões para gerenciar tarefas. Tecnologias: HTML, CSS e JavaScript.

## Funcionalidades

Arraste e solte cartões, adicione colunas e tasks, mude a cor do background, remova colunas e tasks.

## Colaboradores

- 🐧 [@devgraciotim](https://github.com/devgraciotim)
- 🐗 [@conradocmatheus](https://github.com/conradocmatheus)
- 🐵 [@hoesel15](https://github.com/hoesel15)
- 🌊 [@knevctt](https://github.com/knevctt) 
- 🦾 [@PauloGabrielX](https://github.com/PauloGabrielX) 

## Tecnologias Utilizadas

<div>
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg" alt="Tecnologias Utilizadas" width="150px">
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg" alt="Tecnologias Utilizadas" width="150px">
    <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg" alt="Tecnologias Utilizadas" width="150px">
</div>
